// Copyright (c) 2018, ESO and contributors
// For license information, please see license.txt

frappe.ui.form.on('Nat', {
	refresh: function(frm) {

	}
});
