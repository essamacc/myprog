// Copyright (c) 2018, ESO and contributors
// For license information, please see license.txt

frappe.ui.form.on('Person', {
	refresh: function(frm) {

	}
});

 frappe.ui.form.on("Persons_related", "person_code" , function(frm, cdt, cdn) {
		
	var item = locals[cdt][cdn];
	frappe.call({
		method:"frappe.client.get",
		args: { 
		"doctype":"Person"  ,
		"name": item.person_code ,
		},
		callback: function(response) {
			 var c = response.message
			 if (c) {
			      frappe.model.set_value(cdt, cdn, "person_name", c.employee_name)
			      frappe.model.set_value(cdt, cdn, "person_eng_name", c.english_name)
			 } 
			 else {
			      frappe.msgprint("Person not found");
			 }
	}
	});
	frm.refresh_field("Persons_related");
});

