frappe.treeview_settings['Person'] = {
	get_tree_nodes: "infoanalysis.info_analysis.doctype.person.person.get_children",
	filters: [
		{
			fieldname: "company",
			fieldtype:"Select",
			options: "تحليل المعلومات  ",
			label: __("Company"),
			default: "تحليل المعلومات  "
		}
	],
	breadcrumb: "Setting",
	disable_add_node: true,
	get_tree_root: false,
	toolbar: [
		{ toggle_btn: true },
		{
			label:__("تعديل"),
			condition: function(node) {
				return !node.is_root;
			},
			click: function(node) {
				frappe.set_route("Form", "Person", node.data.value);
			}
		}
	],
	menu_items: [
		{
			label: __("شخص جديد"),
			action: function() {
				frappe.new_doc("Person", true);
			},
			condition: 'frappe.boot.user.can_create.indexOf("Person") !== -1'
		}
	],
};
