# -*- coding: utf-8 -*-
# Copyright (c) 2018, ESO and contributors
# For license information, please see license.txt

from __future__ import unicode_literals
import frappe
from frappe.utils import getdate, validate_email_add, today, add_years
from frappe.model.naming import make_autoname
from frappe import throw, _, scrub
import frappe.permissions
from frappe.model.document import Document
from frappe.utils.nestedset import NestedSet


class Person(Document):
#nsm_parent_field = 'reports_to'
#def validate(self):
#    if not self.parent_person:
#        self.parent_person = get_root_of("Person")

	def validate(self):
		self.person = self.name
		self.validate_reports_to()
		value = frappe.db.get_value("Person", filters={"name": self.reports_to}, fieldname="employee_name")
		self.parent_person = value
		

	def on_update(self):
		self.validate_reports_to()

	#def update_nsm_model(self):
	#00		frappe.utils.nestedset.update_nsm(self)

	def validate_reports_to(self):
		if self.reports_to == self.name:
			throw(_("Person cannot report to himself."))

@frappe.whitelist()
def get_children(doctype, parent=None, company=None ,is_root=False, is_tree=False):
	condition = ''
	if is_root:
		parent = ""
	if parent and company and parent!=company:
		condition = ' and reports_to = {0}'.format(frappe.db.escape(parent))
	else:
		condition = ' and ifnull(reports_to, "")=""'
	person = frappe.db.sql(	""" select
			name as value, employee_name as title,
			exists(select name from `tabPerson` where reports_to=per.name) as expandable
		from
			`tabPerson` per
		where docstatus >= 0 {condition} order by name""".format(condition=condition),  as_dict=1)

	# return employee
	return person
